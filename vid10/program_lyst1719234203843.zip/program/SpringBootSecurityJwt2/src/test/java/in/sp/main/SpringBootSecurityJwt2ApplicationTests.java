package in.sp.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityJwt2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
